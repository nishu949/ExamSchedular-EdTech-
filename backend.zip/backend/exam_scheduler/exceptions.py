class ConflictException(Exception):
    pass