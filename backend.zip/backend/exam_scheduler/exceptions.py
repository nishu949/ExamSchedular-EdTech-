class ScheduleConflictException(Exception):
    pass