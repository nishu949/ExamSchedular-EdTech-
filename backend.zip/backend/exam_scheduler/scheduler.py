from datetime import datetime, timedelta

from .models import (
    Course,
    Room,
    Faculty,
    Student,
    Timetable
)

from .exceptions import ScheduleConflictException


class ScheduleEngine:

    def __init__(self):

        self.rooms = sorted(
            list(Room.objects()),
            key=lambda room: room.capacity
        )

        self.courses = list(Course.objects())

        self.faculties = list(Faculty.objects())

        self.students = list(Student.objects())

        self.time_slots = [
            "10:00",
            "14:00"
        ]

    # ---------------------------------------------
    # Faculty Availability Check
    # ---------------------------------------------

    def is_faculty_available(
        self,
        faculty_name,
        exam_date
    ):

        faculty = Faculty.objects(
            faculty_name=faculty_name
        ).first()

        if faculty is None:
            return False

        weekday = exam_date.strftime("%A")

        if weekday not in faculty.available_days:
            return False

        if exam_date in faculty.unavailable_dates:
            return False

        return True

    # ---------------------------------------------
    # Find Suitable Room
    # ---------------------------------------------

    def get_room(self, student_count):

        for room in self.rooms:

            if room.capacity >= student_count:

                return room

        return None

    # ---------------------------------------------
    # Generate Timetable
    # ---------------------------------------------

    def generate(self):

        Timetable.objects.delete()

        room_schedule = {}
        faculty_schedule = {}
        student_schedule = {}

        current_date = datetime.today()
        slot_index = 0
        max_attempts = 100

        if not self.rooms:
            raise ScheduleConflictException("No rooms available")

        if not self.courses:
            raise ScheduleConflictException("No courses available")

        for course in self.courses:

            assigned_room = None
            attempts = 0

            while assigned_room is None:

                attempts += 1

                if attempts > max_attempts:
                    raise ScheduleConflictException(
                        f"Unable to schedule {course.course_code}. "
                        f"Check faculty availability or room capacity."
                    )

                exam_date = current_date.date()
                exam_time = self.time_slots[slot_index]

                room = self.get_room(course.student_count)

                if room is None:
                    raise ScheduleConflictException(
                        f"No room available for {course.course_code}"
                    )

            # Faculty Availability
                if not self.is_faculty_available(course.faculty,exam_date):

                    slot_index += 1

                    if slot_index >= len(self.time_slots):
                        slot_index = 0
                        current_date += timedelta(days=1)

                    continue

                room_key = (room.room_id, exam_date, exam_time)
                faculty_key = (course.faculty,exam_date,exam_time)

            # Room Conflict
                if room_key in room_schedule:

                    slot_index += 1

                    if slot_index >= len(self.time_slots):
                        slot_index = 0
                        current_date += timedelta(days=1)

                    continue

            # Faculty Conflict
                if faculty_key in faculty_schedule:

                    slot_index += 1

                    if slot_index >= len(self.time_slots):
                        slot_index = 0
                        current_date += timedelta(days=1)

                    continue

            # Student Conflict
                clash = False

                for student in course.students:

                    student_key = (student,
                        exam_date,
                        exam_time
                    )

                    if student_key in student_schedule:
                        clash = True
                        break

                if clash:

                    slot_index += 1

                    if slot_index >= len(self.time_slots):
                        slot_index = 0
                        current_date += timedelta(days=1)

                    continue

            # Assign
                assigned_room = room

                room_schedule[room_key] = course.course_code
                faculty_schedule[faculty_key] = course.course_code

                for student in course.students:

                    student_schedule[
                        ( student, exam_date,exam_time )
                    ] = course.course_code

        # Save timetable entry
            Timetable(

            course_code=course.course_code,
            faculty=course.faculty,
            room_id=assigned_room.room_id,
            exam_date=exam_date,
            exam_time=exam_time

            ).save()

            slot_index += 1

            if slot_index >= len(self.time_slots):
                slot_index = 0
                current_date += timedelta(days=1)

        return {"message": "Timetable generated successfully"}